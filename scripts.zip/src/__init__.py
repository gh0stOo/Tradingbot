"""Crypto Trading Bot Package"""

__version__ = "1.0.0"

