"""Test package for Trading Bot"""

